// import { useState, useEffect } from 'react';
// import { motion } from 'framer-motion';
// import { ListMusic, Music, Plus, ChevronDown, ChevronRight, Play } from 'lucide-react';
// import { toast } from 'react-toastify';

// const Playlists = () => {
//   const [playlists, setPlaylists] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [expandedPlaylist, setExpandedPlaylist] = useState(null);

//   useEffect(() => {
//     const fetchPlaylists = async () => {
//       try {
//         const token = localStorage.getItem('token');
//         const response = await fetch('http://localhost:8000/emotion/get_playlists/', {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });

//         const data = await response.json();
//         if (data.success) {
//           setPlaylists(data.playlists);
//         } else {
//           toast.error(data.message || 'Failed to fetch playlists');
//         }
//       } catch (error) {
//         toast.error('Error fetching playlists');
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchPlaylists();
//   }, []);

//   const togglePlaylist = (playlistId) => {
//     setExpandedPlaylist(expandedPlaylist === playlistId ? null : playlistId);
//   };

//   if (loading) {
//     return (
//       <div className="flex justify-center items-center h-64">
//         <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
//       </div>
//     );
//   }

//   return (
//     <div className="space-y-6">
//       <div className="flex items-center justify-between">
//         <h2 className="text-2xl font-bold text-white flex items-center gap-2">
//           <ListMusic className="text-purple-400" />
//           My Playlists
//         </h2>
//         <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg text-sm font-medium transition-colors flex items-center gap-2">
//           <Plus size={16} />
//           New Playlist
//         </button>
//       </div>

//       {playlists.length === 0 ? (
//         <div className="text-center py-12 text-gray-400">
//           <Music className="mx-auto h-12 w-12" />
//           <p className="mt-4">You don't have any playlists yet</p>
//           <button className="mt-4 px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg text-sm font-medium transition-colors">
//             Create your first playlist
//           </button>
//         </div>
//       ) : (
//         <div className="space-y-4">
//           {playlists.map((playlist) => (
//             <motion.div
//               key={playlist.id}
//               initial={{ opacity: 0, y: 10 }}
//               animate={{ opacity: 1, y: 0 }}
//               className="bg-slate-800/50 rounded-xl border border-slate-700/50 overflow-hidden"
//             >
//               <div
//                 className="flex items-center justify-between p-4 cursor-pointer hover:bg-slate-700/30 transition-colors"
//                 onClick={() => togglePlaylist(playlist.id)}
//               >
//                 <div className="flex items-center gap-3">
//                   {expandedPlaylist === playlist.id ? (
//                     <ChevronDown className="text-purple-400" />
//                   ) : (
//                     <ChevronRight className="text-purple-400" />
//                   )}
//                   <h3 className="font-medium text-white">{playlist.name}</h3>
//                   <span className="text-xs bg-purple-500/20 text-purple-400 px-2 py-1 rounded-full">
//                     {playlist.songs.length} songs
//                   </span>
//                 </div>
//                 <div className="text-xs text-gray-400">
//                   Created: {new Date(playlist.created_at).toLocaleDateString()}
//                 </div>
//               </div>

//               {expandedPlaylist === playlist.id && (
//                 <motion.div
//                   initial={{ opacity: 0, height: 0 }}
//                   animate={{ opacity: 1, height: 'auto' }}
//                   exit={{ opacity: 0, height: 0 }}
//                   className="bg-slate-800/30 border-t border-slate-700/50"
//                 >
//                   <div className="divide-y divide-slate-700/50">
//                     {playlist.songs.length > 0 ? (
//                       playlist.songs.map((song) => (
//                         <div key={song.id} className="p-4 hover:bg-slate-700/20 transition-colors">
//                           <div className="flex items-center gap-4">
//                             <div className="relative">
//                               <img
//                                 src={song.thumbnail_url}
//                                 alt={song.title}
//                                 className="w-12 h-12 rounded-lg object-cover"
//                               />
//                               <button className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 bg-black/50 rounded-lg transition-opacity">
//                                 <Play className="text-white" size={16} />
//                               </button>
//                             </div>
//                             <div className="flex-1">
//                               <h4 className="font-medium text-white">{song.title}</h4>
//                               <p className="text-xs text-gray-400 mt-1">
//                                 Added: {new Date(song.added_at).toLocaleDateString()}
//                               </p>
//                             </div>
//                             <a
//                               href={song.url}
//                               target="_blank"
//                               rel="noopener noreferrer"
//                               className="text-xs text-purple-400 hover:text-purple-300"
//                             >
//                               View
//                             </a>
//                           </div>
//                         </div>
//                       ))
//                     ) : (
//                       <div className="p-4 text-center text-gray-400">
//                         No songs in this playlist yet
//                       </div>
//                     )}
//                   </div>
//                 </motion.div>
//               )}
//             </motion.div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// };

// export default Playlists;

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ListMusic, Music, Plus, ChevronDown, ChevronRight, Play } from 'lucide-react';
import { toast } from 'react-toastify';

const Playlists = () => {
  const [playlists, setPlaylists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedPlaylist, setExpandedPlaylist] = useState(null);

  useEffect(() => {
    const fetchPlaylists = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:8000/emotion/get_playlists/', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await response.json();
        if (data.success) {
          setPlaylists(data.playlists);
        } else {
          toast.error(data.message || 'Failed to fetch playlists');
        }
      } catch (error) {
        toast.error('Error fetching playlists');
      } finally {
        setLoading(false);
      }
    };

    fetchPlaylists();
  }, []);

  const togglePlaylist = (playlistId) => {
    setExpandedPlaylist(expandedPlaylist === playlistId ? null : playlistId);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 bg-gradient-to-br from-slate-800 via-blue-900 to-slate-900 p-6 rounded-lg">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-teal-500 bg-clip-text text-transparent flex items-center gap-2">
          <ListMusic className="text-cyan-400" />
          My Playlists
        </h2>
        <button className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-teal-600 hover:from-cyan-600 hover:to-teal-700 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 text-white">
          <Plus size={16} />
          New Playlist
        </button>
      </div>

      {playlists.length === 0 ? (
        <div className="text-center py-12 text-gray-400">
          <Music className="mx-auto h-12 w-12 text-cyan-400" />
          <p className="mt-4">You don't have any playlists yet</p>
          <button className="mt-4 px-4 py-2 bg-gradient-to-r from-cyan-500 to-teal-600 hover:from-cyan-600 hover:to-teal-700 rounded-lg text-sm font-medium text-white">
            Create your first playlist
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {playlists.map((playlist) => (
            <motion.div
              key={playlist.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-800/80 rounded-xl border border-cyan-500/30 overflow-hidden shadow-cyan-500/10"
            >
              <div
                className="flex items-center justify-between p-4 cursor-pointer hover:bg-cyan-500/10 transition-colors"
                onClick={() => togglePlaylist(playlist.id)}
              >
                <div className="flex items-center gap-3">
                  {expandedPlaylist === playlist.id ? (
                    <ChevronDown className="text-cyan-400" />
                  ) : (
                    <ChevronRight className="text-cyan-400" />
                  )}
                  <h3 className="font-medium text-cyan-100">{playlist.name}</h3>
                  <span className="text-xs bg-cyan-500/20 text-cyan-400 px-2 py-1 rounded-full">
                    {playlist.songs.length} songs
                  </span>
                </div>
                <div className="text-xs text-gray-400">
                  Created: {new Date(playlist.created_at).toLocaleDateString()}
                </div>
              </div>

              {expandedPlaylist === playlist.id && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-slate-800/50 border-t border-cyan-500/30"
                >
                  <div className="divide-y divide-cyan-500/30">
                    {playlist.songs.length > 0 ? (
                      playlist.songs.map((song) => (
                        <div key={song.id} className="p-4 hover:bg-cyan-500/10 transition-colors">
                          <div className="flex items-center gap-4">
                            <div className="relative">
                              <img
                                src={song.thumbnail_url}
                                alt={song.title}
                                className="w-12 h-12 rounded-lg object-cover"
                              />
                              <button className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 bg-black/50 rounded-lg transition-opacity">
                                <Play className="text-cyan-400" size={16} />
                              </button>
                            </div>
                            <div className="flex-1">
                              <h4 className="font-medium text-gray-300">{song.title}</h4>
                              <p className="text-xs text-gray-400 mt-1">
                                Added: {new Date(song.added_at).toLocaleDateString()}
                              </p>
                            </div>
                            <a
                              href={song.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs text-cyan-400 hover:text-cyan-300"
                            >
                              View
                            </a>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-4 text-center text-gray-400">
                        No songs in this playlist yet
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Playlists;