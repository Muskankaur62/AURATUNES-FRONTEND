
// (this is the new code)
import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import MusicPlayer from '../../pages/MusicPlayer';

const LiveEmotionDetection = () => {
  const [emotion, setEmotion] = useState('');
  const [previousEmotion, setPreviousEmotion] = useState('');
  const [pendingEmotion, setPendingEmotion] = useState('');
  const [recommendations, setRecommendations] = useState([]);
  const [pendingRecommendations, setPendingRecommendations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('Hindi');
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const intervalRef = useRef(null);
  const [faceBox, setFaceBox] = useState(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoRef.current.srcObject = stream;
      setIsCameraOn(true);
      startDetection();
    } catch (err) {
      toast.error('Error accessing camera');
      setIsLoading(false);
    }
  };

  const captureAndAnalyze = async () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext('2d');

    // Set canvas dimensions to match video's intrinsic dimensions
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    canvas.toBlob(async (blob) => {
      const formData = new FormData();
      formData.append('image', blob, 'frame.jpg');
      formData.append('language', selectedLanguage);

      try {
        const response = await axios.post('http://localhost:8000/emotion/emotion_detection/', formData, {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'multipart/form-data'
          }
        });

        if (response.data.success) {
          // Scale coordinates from backend to match displayed video size
          const videoElement = videoRef.current;
          const scaleX = videoElement.offsetWidth / videoElement.videoWidth;
          const scaleY = videoElement.offsetHeight / videoElement.videoHeight;

          const faceCoords = response.data.face_coordinates;
          if (faceCoords) {
            setFaceBox({
              x: faceCoords.x * scaleX,
              y: faceCoords.y * scaleY,
              width: faceCoords.width * scaleX,
              height: faceCoords.height * scaleY
            });
          }

          const newEmotion = response.data.emotion;
          if (newEmotion !== previousEmotion) {
            setPendingEmotion(newEmotion);
            setPendingRecommendations([...response.data.recommendations]);
            setShowConfirmation(true);
          }
        }
      } catch (error) {
        toast.error('Error analyzing frame');
      }
    }, 'image/jpeg');
  };

  const startDetection = () => {
    // Clear any existing interval
    if (intervalRef.current) clearInterval(intervalRef.current);
    
    // Start new interval with 5-second detection
    intervalRef.current = setInterval(captureAndAnalyze, 5000);
    setIsLoading(false);
    captureAndAnalyze(); // Immediate first detection
  };

  const handleLanguageChange = (language) => {
    setSelectedLanguage(language);
    if (isCameraOn) {
      // Trigger immediate detection when language changes
      captureAndAnalyze();
    }
  };

  const handleUserChoice = (choice) => {
    if (choice === 'yes') {
      setEmotion(pendingEmotion);
      setPreviousEmotion(pendingEmotion);
      setRecommendations(pendingRecommendations);
    }
    setShowConfirmation(false);
    setPendingEmotion('');
    setPendingRecommendations([]);
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (videoRef.current?.srcObject) {
        videoRef.current.srcObject.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f172a] to-[#1e293b] text-slate-100 p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-5xl font-bold text-center mb-8 bg-gradient-to-r from-[#7dd3fc] to-[#3b82f6] bg-clip-text text-transparent tracking-wide">
          AuraTunes Detection
        </h1>
        
        {/* Language Selection Buttons */}
        <div className="flex justify-center gap-4 mb-8">
          {['English', 'Hindi', 'Punjabi'].map((language) => (
            <motion.button
              key={language}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleLanguageChange(language)}
              className={`px-6 py-2 rounded-lg font-medium transition-all ${
                selectedLanguage === language
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20'
                  : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700/70'
              }`}
            >
              {language}
            </motion.button>
          ))}
        </div>
        
        <div className="relative mb-8 group">
          <video
            ref={videoRef}
            autoPlay
            muted
            className="w-full h-96 object-cover rounded-xl shadow-2xl shadow-blue-900/50 border-2 border-slate-700/50"
            style={{ display: isCameraOn ? 'block' : 'none' }}
          />
          
          {faceBox && (
            <div
              className="absolute border-4 border-emerald-400 rounded-lg shadow-lg shadow-emerald-500/30"
              style={{
                left: `${faceBox.x}px`,
                top: `${faceBox.y}px`,
                width: `${faceBox.width}px`,
                height: `${faceBox.height}px`,
              }}
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-8 left-0 bg-gradient-to-br from-emerald-500 to-cyan-500 px-4 py-2 rounded-lg font-bold"
              >
                <span className="text-xl text-slate-900">{emotion}</span>
              </motion.div>
            </div>
          )}
          
          <canvas ref={canvasRef} className="hidden" />
        </div>

        {!isCameraOn && (
          <div className="text-center">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={startCamera}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:to-blue-700 text-white px-8 py-4 rounded-xl text-lg font-bold tracking-wide transition-all duration-300 shadow-lg shadow-cyan-500/20"
            >
              {isLoading ? 'Starting Detection...' : 'Start Emotion Detection'}
            </motion.button>
          </div>
        )}

        {showConfirmation && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-cyan-100 text-slate-900 p-6 rounded-xl mt-6 text-center shadow-lg shadow-cyan-500/20 border-2 border-cyan-400"
          >
            <p className="mb-4 font-semibold text-lg">
              New emotion detected: <span className="text-blue-600 font-bold">{pendingEmotion}</span>. 
              <br />Do you want to update recommendations?
            </p>
            <div className="flex justify-center gap-6">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleUserChoice('yes')}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-6 py-3 rounded-lg font-bold shadow-md shadow-cyan-500/30"
              >
                Yes, Update
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleUserChoice('no')}
                className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-6 py-3 rounded-lg font-bold shadow-md shadow-blue-500/30"
              >
                No, Keep Current
              </motion.button>
            </div>
          </motion.div>
        )}

        {recommendations.length > 0 && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }}
            className="border-t-2 border-slate-700/50 pt-8 mt-12"
          >
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-slate-100 mb-2">
                Recommended for your {emotion.toLowerCase()} mood
              </h2>
              <p className="text-slate-400">
                Selected language: {selectedLanguage}
              </p>
            </div>
            <MusicPlayer recommendations={recommendations} />
          </motion.div>
        )}
      </div>
      
      <ToastContainer 
        position="bottom-right"
        toastClassName="bg-slate-800/90 text-slate-100"
      />
    </div>
  );
};

export default LiveEmotionDetection;